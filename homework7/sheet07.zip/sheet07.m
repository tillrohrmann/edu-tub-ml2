function sheet07

%
% SINC DATA
%
figure(1)

% generate some data
[X, Y] = sincdata(100, 0.1);

% generate the kernel matrix
K = rbfkern(0.1, X);
 
% Run rde
[D, Yh] = rde(K, Y);

% plot the data
plot_fit(X, Y, Yh);
title(sprintf('sinc data set, effective dimensionality = %d', D));

%
% SINE DATA
%
figure(2)

% generate some data
[X, Y] = sinedata(100, 4);

% generate the kernel matrix
K = rbfkern(0.1, X);
 
% Run rde
[D, Yh] = rde(K, Y);

% plot the data
plot_fit(X, Y, Yh);
title(sprintf('sine data set, effective dimensionality = %d', D));

end

function K = rbfkern(w, X)
N = size(X, 1);
XX = sum(X.*X, 2);
D = repmat(XX, 1, N) + repmat(XX', N, 1) - 2 * X * X';
K = exp(-D/(2*w));

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Insert your solutions below
%

function [X, Y] = sincdata(N, r)
% ...
end

function [X, Y] = sinedata(N, K)
% ...
end

function [D, Yh] = rde(K, Y)
% ...
end

function plot_fit(X, Y, Yh)
% ...
end