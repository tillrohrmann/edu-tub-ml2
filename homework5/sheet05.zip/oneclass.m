function alpha = oneclass(K, C)
% inputs:  K      N x N kernel matrix
%          C      regularization constant
% outputs: alpha  N-dimensional dual solution vector
